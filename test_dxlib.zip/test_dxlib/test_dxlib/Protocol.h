#ifndef ProtocolH
#define ProtocolH
//---------------------------------------------------------------------------

typedef struct _PROTOCOL_ETHER {
	unsigned char Mac[2][6];
	short int Type;
} PROTOCOL_ETHER, *LP_PROTOCOL_ETHER;

typedef struct _PROTOCOL_ARP {
	short int HwType;
	short int Type;
	unsigned char HwLen;
	unsigned char ProtoLen;
	short int Code;
	unsigned char SrcMac[6];
	unsigned int SrcIp;
	unsigned char DstMac[6];
	unsigned int DstIp;
} PROTOCOL_ARP, *LP_PROTOCOL_ARP;

typedef struct _PROTOCOL_IP {
	unsigned char Ver_Len;
	unsigned char TOS;
	short int TotalLen;
	short int Ident;
	short int Flags;
	unsigned char TTL;
	unsigned char Protocol;
	short int CheckSum;
	unsigned int Ip[2];
	unsigned char *option;
} PROTOCOL_IP, *LP_PROTOCOL_IP;

typedef struct _PROTOCOL_TCP {
	short int Port[2];
	unsigned int Squence;
	unsigned int Ack;
	unsigned char Offset;
	unsigned char FLG;
	short int Window;
	short int CheckSum;
	short int Urgent;
	unsigned char Option;
} PROTOCOL_TCP, *LP_PROTOCOL_TCP;

typedef struct _PROTOCOL_UDP {
	short int Port[2];
	short int UdpLen;
	short int CheckSum;
} PROTOCOL_UDP, *LP_PROTOCOL_UDP;

typedef struct _PROTOCOL_ICMP {
	unsigned char Type;
	unsigned char Code;
	short int CheckSum;
} PROTOCOL_ICMP, *LP_PROTOCOL_ICMP;

extern unsigned int _fastcall _uint(unsigned int p);

extern char *PROTOCOL_NAME[];

#endif
