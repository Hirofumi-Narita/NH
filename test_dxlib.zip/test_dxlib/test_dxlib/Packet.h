#ifndef PACKETH
#define PACKETH
//---------------------------------------------------------------------------
#include <string>

#define IP_PACKET 0x0800
#define ARP_PACKET 0x0806

struct  Packet{
	std::string mac[2];
	unsigned int type;
	std::string ip[2];
	std::string ip_protocol;
};

extern int PacketAnalysis(unsigned char *buffer, Packet *packet);

#endif