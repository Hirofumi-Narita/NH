#ifndef PROTH
#define PROTH
//---------------------------------------------------------------------------
#include<map>
using namespace std;

class PORT_NAME {
private:
	map<string, char*> name;
public:
	PORT_NAME() {
		name["20"] = "FTP";
		name["21"] = "FTP";
		name["22"] = "ssh";
		name["23"] = "Telnet";
		name["80"] = "HTTP";
		name["443"] = "HTTPS";
	}
	void get(char s[]) {
		string str = s;
		auto it = name.find(str);
		if (it != name.end()) {
			cout << name[str] << endl;
		}
	}
};


#endif