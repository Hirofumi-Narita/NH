#include "DxLib.h"
#include <cmath>
#include <vector>
#include<iostream>
#include"Protocol.h"
#include"Captuer.h"
#include"Packet.h"
#include <thread>
using namespace std;

#define RAD 3.1415926f / 180
#define MAX 15
#define R 200

struct IP {
	int x;
	int y;
	double si;
	double co;
};

struct PAC {
	int x;
	int y;
	int cnt;
	int _ip;
};

IP ip[MAX];
vector<PAC> pac;
int ip_n;

void SetIpCircle(int i);
void AddPac(int _ip);
//-----------------------------------------------------------------------
//�A�_�v�^�[
unsigned long AddressList[MAX_ADAPTER];
char NameList[MAX_ADAPTER][1024];
int max, flg = 1;

//�p�P�b�g�̃o�b�t�@
unsigned char Buffer[MAX_PACKET_SIZE];

Packet packet;

vector<string> ip_list;
//-----------------------------------------------------------------------

int packet_print(unsigned char *buffer);
int CheckPacket();

void do_worker1() {
	LoadAdapter(AddressList, NameList, &max);
	OpenAdapter(NameList[2]);
	try {
		chrono::milliseconds dura(300);
		while (flg) {
			if (GetPacket(Buffer)) {
				PacketAnalysis(Buffer, &packet);
				AddPac(CheckPacket());
				//this_thread::sleep_for(dura);
			}
		}
	}
	catch (exception &ex) {}

	CloseAdapter();
}

// �v���O������ WinMain ����n�܂�܂�
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	ChangeWindowMode(TRUE);
	if (DxLib_Init() == -1) return -1;
	SetDrawScreen(DX_SCREEN_BACK);
	
	thread t1(do_worker1);
	
	while (ScreenFlip() == 0 && ProcessMessage() == 0 && ClearDrawScreen() == 0) {
		
		DrawCircle(320, 240, 20, GetColor(255, 255, 255), TRUE); //�^��

		for (int i = 0; i < ip_n; i++) {
			SetIpCircle(i);
			DrawCircle(ip[i].x, ip[i].y, 20, GetColor(0, 0, 255), TRUE);
			DrawString(ip[i].x - 10, ip[i].y, ip_list[i].c_str(), GetColor(255, 255, 255));
		}
		auto itr = pac.begin();
		while (itr != pac.end()) {
			itr->x = (int)(320 + itr->cnt * ip[itr->_ip].co);
			itr->y = (int)(240 + itr->cnt * ip[itr->_ip].si);
			itr->cnt += 4;
			if (itr->cnt <= 200) {
				DrawCircle(itr->x, itr->y, 3, GetColor(255, 255, 255), TRUE);
				itr++;
			}	
			else {
				itr = pac.erase(itr);
			}
		}
	}
	flg = 0;
	t1.join();
	DxLib_End();

	return 0;
}

void AddPac(int _ip) {
	if (_ip < 0) return;
	PAC t;
	t.x = 320; 
	t.y = 240; 
	t._ip = _ip; 
	t.cnt = 1;
	pac.push_back(t);
}

void SetIpCircle(int i) {
	if (ip_n <= 0) return;
	int tmp = 360 / ip_n;
	ip[i].x = (int)(320 + R * cos(RAD * i * tmp));
	ip[i].y = (int)(240 + R * sin(RAD * i * tmp));
	ip[i].si = sin(RAD * i * tmp);
	ip[i].co = cos(RAD * i * tmp);
}

int CheckPacket() {
	int i = 1;
	string name = packet.ip[0];
	for (i = 0;i < (int)ip_list.size();i++) {
		if (ip_list[i] == name) {
			return i;
		}
	}

	if (ip_n >= 10) return -1;
	ip_list.push_back(name);
	ip_n++;

	return i;
}